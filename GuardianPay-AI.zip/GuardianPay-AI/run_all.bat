@echo off
title GuardianPay AI Launcher
echo ========================================================
echo        GUARDIANPAY AI - DETECT. WARN. PROTECT.
echo      Innovation Unbound Hackathon @ VIT Chennai
echo ========================================================
echo.
echo [1/2] Starting Backend Server (FastAPI on Port 8000)...
start "GuardianPay AI - Backend API" cmd /k "cd backend && python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload"

echo [2/2] Starting Frontend App (React on Port 5173)...
start "GuardianPay AI - Frontend Web" cmd /k "cd frontend && npm run dev"

echo.
echo ========================================================
echo Both Backend (Port 8000) and Frontend (Port 5173) are running!
echo Frontend URL : http://127.0.0.1:5173
echo Backend Docs : http://127.0.0.1:8000/docs
echo ========================================================
echo.
timeout /t 3 >nul
start http://127.0.0.1:5173
exit
