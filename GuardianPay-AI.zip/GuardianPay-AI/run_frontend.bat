@echo off
echo ===================================================
echo Starting GuardianPay AI Frontend (Vite + React)...
echo ===================================================
cd frontend
npm run dev
pause
